# -*- coding: utf-8 -*-

#This plugin is free software, you are allowed to
#modify it (if you keep the license),
#but you are not allowed to distribute/publish
#it without source code (this version and your modifications).
#This means you also have to distribute
#source code of your modifications.

# Edit By RAED 08-10-2021 (Support python3)

from Components.MenuList import MenuList
from Tools.Directories import SCOPE_SKIN_IMAGE, resolveFilename
from enigma import RT_HALIGN_LEFT, eListboxPythonMultiContent, gFont
from Tools.LoadPixmap import LoadPixmap
import skin

def QuickButtonListEntry(key, text):
	res = [ text ]
	if text[0] == "--":
		png = LoadPixmap(resolveFilename(SCOPE_SKIN_IMAGE, "/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/op_separator.png"))
		if png != None:
			x, y, w, h = skin.parameters.get("MultiQuickButtonListPic1", (0,12,780,25))
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, x, y, w, h, png))
	else:
		x, y, w, h = skin.parameters.get("MultiQuickButtonList", (45,0,780,25))
		res.append((eListboxPythonMultiContent.TYPE_TEXT, x, y, w, h, 0, RT_HALIGN_LEFT, text[0]))
		if key == "green" or key == "red":
			path = "/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/" + key + ".png"
		else:
			path = "skin_default/buttons/key_" + key + ".png"
		png = LoadPixmap(resolveFilename(SCOPE_SKIN_IMAGE, (path)))
		if png != None:
			x, y, w, h = skin.parameters.get("MultiQuickButtonListPic2", (5,0,35,25))
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, x, y, w, h, png))
	return res

class QuickButtonList(MenuList):
	def __init__(self, list, selection = 0, enableWrapAround=False):
		MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
		font, size = skin.parameters.get("MultiQuickButtonListFont", ('Regular',20))
		self.l.setFont(0, gFont(font, size))
		self.l.setItemHeight(25)
		self.selection = selection

	def postWidgetCreate(self, instance):
		MenuList.postWidgetCreate(self, instance)
		self.moveToIndex(self.selection)
