# -*- coding: utf-8 -*-
# Multi QuickButton Rel. 2.7
# from Emanuel CLI 2009
#
# ***special thanks*** to Dr.Best & AliAbdul ;-)
# modified for VU+ by <info@vuplus-support.org>
# modified version is based on original MQB version 2.7

#This plugin is free software, you are allowed to
#modify it (if you keep the license),
#but you are not allowed to distribute/publish
#it without source code (this version and your modifications).
#This means you also have to distribute
#source code of your modifications.

# Edit By RAED 08-10-2021 (Support python3)

# python3
from __future__ import print_function

from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Screens.ChannelSelection import ChannelSelection
from Screens.MessageBox import MessageBox
from Screens.InfoBarGenerics import InfoBarPlugins
from Screens.InfoBar import MoviePlayer, InfoBar
from Components.ActionMap import ActionMap
from Components.PluginComponent import plugins
from Components.SystemInfo import SystemInfo
from Components.config import config, ConfigSubsection, ConfigYesNo
from Plugins.Plugin import PluginDescriptor
from .QuickButtonXML import QuickButtonXML
from .MultiQuickButton import MultiQuickButton, QuickButton

import xml.sax.xmlreader
import os.path
import os
import keymapparser

baseInfoBarPlugins__init__ = None
baserunPlugin = None
StartOnlyOneTime = False
orig_MoviePlayer__init__ = None

def autostart(reason, **kwargs):
	if reason == 0:
		if config.plugins.QuickButton.enable.value:
			print("[MultiQuickButton] enabled: ",config.plugins.QuickButton.enable.getValue())
			global baseInfoBarPlugins__init__, baserunPlugin, orig_MoviePlayer__init__
			if "session" in kwargs:
				session = kwargs["session"]
				checkMQBKeyMapFile()
				if baseInfoBarPlugins__init__ == None:
					baseInfoBarPlugins__init__ = InfoBarPlugins.__init__
				if baserunPlugin == None:
					baserunPlugin = InfoBarPlugins.runPlugin
				if orig_MoviePlayer__init__ == None:
					orig_MoviePlayer__init__ = MoviePlayer.__init__
				InfoBarPlugins.__init__ = InfoBarPlugins__init__
				InfoBarPlugins.runPlugin = runPlugin
				InfoBarPlugins.checkQuickSel = checkQuickSel
				InfoBarPlugins.askForQuickList = askForQuickList
				InfoBarPlugins.getQuickList = getQuickList
				InfoBarPlugins.execQuick = execQuick
				InfoBarPlugins.quickSelectGlobal = quickSelectGlobal
				if config.plugins.QuickButton.enable_movieplayer.value:
					MoviePlayer.__init__ = MoviePlayer__init__
				gMQBActionStrings.updateInfoBarColorKeys()
				
		else:
			print("[MultiQuickButton] disabled")
	else:
		print("[MultiQuickButton] checking keymap.xml...")
		rePatchKeymap()

def checkMQBKeyMapFile():
	user_mqb_keymap_file = "/etc/MultiQuickButton/keymap.xml"
	plugin_mqb_keymap_file = "/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/keymap_orig.xml"
	if not os.path.exists(user_mqb_keymap_file):
		os.system ("cp %s %s" % (plugin_mqb_keymap_file, user_mqb_keymap_file))
	if os.path.exists(user_mqb_keymap_file):	
		keymapparser.readKeymap(user_mqb_keymap_file)

def rePatchKeymap():
	globalkeymapfile = "/usr/share/enigma2/keymap.xml"
	globalkeymap = open(globalkeymapfile, "r")
	text = globalkeymap.read()
	text_orig = text
	globalkeymap.close()
	globalkeys = [ 	"<key id=\"KEY_YELLOW\" mapto=\"timeshiftStart\" flags=\"m\" />", \
			"<key id=\"KEY_YELLOW\" mapto=\"timeshiftActivateEndAndPause\" flags=\"m\" />", \
			"<key id=\"KEY_VIDEO\" mapto=\"showMovies\" flags=\"m\" />", \
			"<key id=\"KEY_RADIO\" mapto=\"showRadio\" flags=\"m\" />", \
			"<key id=\"KEY_TEXT\" mapto=\"startTeletext\" flags=\"m\" />", \
			"<key id=\"KEY_HELP\" mapto=\"displayHelp\" flags=\"m\" />" ]
	for globalkey in globalkeys:
		globalkeyreplace = globalkey.replace("\"m\"", "\"b\"")
		text = text.replace(globalkey, globalkeyreplace)
	if text_orig != text:
		globalkeymap = open(globalkeymapfile, "w")
		globalkeymap.write(text)
		globalkeymap.close()

def InfoBarPlugins__init__(self):
	global StartOnlyOneTime
	if not StartOnlyOneTime:
		StartOnlyOneTime = True
		
		self["QuickButtonActions"] = MQBActionMap(["QuickButtonActions"],
			{
				"red": self.quickSelectGlobal,
				"red_long": self.quickSelectGlobal,
				"green": self.quickSelectGlobal,
				"green_long": self.quickSelectGlobal,
				"yellow": self.quickSelectGlobal,
				"yellow_long": self.quickSelectGlobal,
				"blue": self.quickSelectGlobal,
				"blue_long": self.quickSelectGlobal,
				"pvr": self.quickSelectGlobal,
				"pvr_long": self.quickSelectGlobal,
				"radio": self.quickSelectGlobal,
				"radio_long": self.quickSelectGlobal,
				"tv": self.quickSelectGlobal,
				"text": self.quickSelectGlobal,
				"text_long": self.quickSelectGlobal,
				"help_long": self.quickSelectGlobal,
				"info": self.quickSelectGlobal,
				"info_long": self.quickSelectGlobal,
				"end": self.quickSelectGlobal,
				"end_long": self.quickSelectGlobal,
				"home": self.quickSelectGlobal,
				"home_long": self.quickSelectGlobal,
				"subtitle": self.quickSelectGlobal,
				"cross_up": self.quickSelectGlobal,
				"cross_down": self.quickSelectGlobal,
				"cross_left": self.quickSelectGlobal,
				"cross_right": self.quickSelectGlobal,
				"channeldown": self.quickSelectGlobal,
				"channelup": self.quickSelectGlobal,
				"next": self.quickSelectGlobal,
				"previous": self.quickSelectGlobal,
				"audio": self.quickSelectGlobal,
				"ok": self.quickSelectGlobal,
				"exit": self.quickSelectGlobal,	
				"play": self.quickSelectGlobal,
				"stop": self.quickSelectGlobal,	
				"pause": self.quickSelectGlobal,	
				"fastforward": self.quickSelectGlobal,	
				"rewind": self.quickSelectGlobal,	
				"f1": self.quickSelectGlobal,
				"f2": self.quickSelectGlobal,
				"f3": self.quickSelectGlobal,
			})
		
		self["GlobalQuickButtonActions"] = MQBActionMap(["GlobalQuickButtonActions"],
			{
				"mqb_volup": self.quickSelectGlobal,
				"mqb_voldown": self.quickSelectGlobal,
				"mqb_mute": self.quickSelectGlobal,
				"mqb_power": self.quickSelectGlobal,
				"mqb_power_long": self.quickSelectGlobal,
			}, -1)
	else:
		InfoBarPlugins.__init__ = InfoBarPlugins.__init__
		InfoBarPlugins.runPlugin = InfoBarPlugins.runPlugin
		InfoBarPlugins.quickSelectGlobal = None
	baseInfoBarPlugins__init__(self)

def MoviePlayer__init__(self, arg1_session, arg2_service):
	InfoBarPlugins.quickSelectGlobal = quickSelectGlobal
	self["QuickButtonActions"] = MQBActionMap(["QuickButtonActions"],
			{
				"red": self.quickSelectGlobal,
				"red_long": self.quickSelectGlobal,
				"yellow": self.quickSelectGlobal,
				"yellow_long": self.quickSelectGlobal,
				"blue": self.quickSelectGlobal,
				"blue_long": self.quickSelectGlobal,
			}, -2)
	orig_MoviePlayer__init__(self, arg1_session, arg2_service)

def runPlugin(self, plugin):
	baserunPlugin(self,plugin)

def checkQuickSel(self, path):
	list = None
	button = os.path.basename(path)[12:-4]
	try:
		menu = xml.dom.minidom.parse(path)
		db = QuickButtonXML(menu)
		list = db.getSelection()
	except Exception as e:
		self.session.open(MessageBox,("XML " + _("Error") + ": %s" % (e)),  MessageBox.TYPE_ERROR)
		print("[MultiQuickbutton] ERROR: ",e)
		
	if list != None:
		if len(list) == 1:
			self.execQuick(list[0])
		elif len(list) > 1:
			self.session.openWithCallback(self.askForQuickList,ChoiceBox,"Multi Quickbutton Menu %s" % (button), self.getQuickList(list))
		else:
			if os.path.exists(path):
				self.session.open(QuickButton, path, (_('Quickbutton: Key ') + button))
			else:
				self.session.open(MessageBox,(_("file %s not found!") % (path)),  MessageBox.TYPE_ERROR)

def askForQuickList(self, res):
	if res == None:
		pass
	else:
		self.execQuick(res)

def getQuickList(self, list):
	quickList = []
	for e in list:
		e2 = [_(e[0]), e[1], e[2], e[3], e[4], e[5]]
		quickList.append((e2))
		
	return quickList

def execQuick(self,entry):
	if entry != None:
		if entry[3] != "":
			try:
				module_import = "from " + entry[3] + " import *"
				exec(module_import)
				if entry[4] != "":
					try:
						screen = "self.session.open(" + entry[4] + ")"
						exec(screen)
					except Exception as e:
						self.session.open(MessageBox,("Screen " + _("Error") + ": %s" % (e)),  MessageBox.TYPE_ERROR)
			except Exception as e:
				self.session.open(MessageBox,("Module " + _("Error") + ": %s" % (e)),  MessageBox.TYPE_ERROR)
		if entry[5] != "":
			try:
				exec(entry[5])
			except Exception as e:
				self.session.open(MessageBox,("Code " + _("Error") + ": %s" % (e)),  MessageBox.TYPE_ERROR)

def quickSelectGlobal(self, key):
	if key:
		path = '/etc/MultiQuickButton/quickbutton_' + key + '.xml'
		if os.path.exists(path):
			self.checkQuickSel(path)
		else:
			self.session.open(MessageBox,("file %s not found!" % (path)),  MessageBox.TYPE_ERROR)

class MQBActionMap(ActionMap):
	def action(self, contexts, action):
		quickSelection = ("red", "red_long", "green", "green_long", "yellow", "yellow_long", "blue", "blue_long", "pvr", "pvr_long", "radio", "radio_long", \
				  "text", "text_long", "help_long", "info", "info_long", "end", "end_long", "home", "home_long", "cross_up", "cross_down", "cross_left", \
				  "cross_right", "previous", "next", "channelup", "channeldown", "f1", "f2", "f3", "audio", "exit", "ok", "play", "pause", "rewind", \
				  "fastforward", "stop", "tv", "subtitle", "mqb_volup", "mqb_voldown", "mqb_mute", "mqb_power", "mqb_power_long")
		if (action in quickSelection and action in self.actions):
			res = self.actions[action](action)
			if res != None:
				return res
			return 1
		else:
			return ActionMap.action(self, contexts, action)

class MQBActionStrings:
	
	def __init__(self):
		self.orig_key_dic = {}
		try:
			self.orig_key_dic["KeyRedText"] = SystemInfo["KeyRedText"]
		except Exception as e:
			print("[MultiQuickbutton] KeyRedText not found: ",e)
		try:
			self.orig_key_dic["KeyGreenText"] = SystemInfo["KeyGreenText"]
		except Exception as e:
			print("[MultiQuickbutton] KeyGreenText not found: ",e)
		try:
			self.orig_key_dic["KeyYellowText"] = SystemInfo["KeyYellowText"]
		except Exception as e:
			print("[MultiQuickbutton] KeyYellowText not found: ",e)
		try:
			self.orig_key_dic["KeyBlueText"] = SystemInfo["KeyBlueText"]
		except Exception as e:
			print("[MultiQuickbutton] KeyBlueText not found: ",e)

	def updateInfoBarColorKeys(self):
		for key in ("Red", "Green", "Yellow", "Blue"):
			txt = ""
			if key == "Red":
				txt = self.createList("KEY_01_red")
			elif key == "Green":
				txt = self.createList("KEY_03_green")
			elif key == "Yellow":
				txt = self.createList("KEY_05_yellow")
			elif key == "Blue":
				txt = self.createList("KEY_07_blue")
			
			if txt == "":
				try:
					SystemInfo["Key" + key + "Text"] = self.orig_key_dic["Key" + key + "Text"]
				except:
					pass
			else:
				try:
					SystemInfo["Key" + key + "Text"] = txt
				except:
					pass

		try:
			if InfoBar and InfoBar.instance:
				InfoBar.instance.updateColorKeyInfo()
		except:
			pass

	def createList(self, button):
		ret = ""
		functions = self.getAvailableButtons(button)
		for x in functions:
			functionbutton = " ["
			path = "/etc/MultiQuickButton/quickbutton_" + x[1] + ".xml"
			menu = xml.dom.minidom.parse(path)
			self.XML_db = QuickButtonXML(menu)
			for a in self.XML_db.getMenu():
				if a[1] == "1":
					functionbutton = _(a[0])
					break
			if functionbutton == " [":
				space1 = " "
				space2 = " "
				functionbutton = " "
			ret = functionbutton
		return ret

	def getAvailableButtons(self, button):
		b_list = []
		from .MultiQuickButton import getKeyDic, mqbkeymapfile
		plugin_mqb_keymap_file = "/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/keymap_orig.xml"
		if not os.path.exists(mqbkeymapfile):
			os.system ("cp %s %s" % (plugin_mqb_keymap_file, mqbkeymapfile))
		if not os.path.exists(mqbkeymapfile):
			return b_list
		mqbkeymap = open(mqbkeymapfile, "r")
		text = mqbkeymap.read()
		mqbkeymap.close()
		keys = getKeyDic()
		for key in keys:
			if key == button:
				keyinactive = "<!-- " + keys[key][0] + " -->"
				if keyinactive in text:
					pass
				else:
					b_list.append((key, keys[key][2], keys[key][1]))
				break
		b_list = sorted(b_list, key = lambda item: item[0])
		return b_list

gMQBActionStrings = MQBActionStrings()

def main(session,**kwargs):
	session.open(MultiQuickButton)

def menu(menuid, **kwargs):
	if menuid == "mainmenu":
		return [(_("Multi Quickbutton"), main, "multi_quick", 55)]
	return []

def Plugins(**kwargs):
	if config.plugins.QuickButton.mainmenu.value:
		return [PluginDescriptor(
				where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART],
				fnc = autostart),
				PluginDescriptor(
				name="Multi Quickbutton",
				description="Multi Quickbutton for Keyboard and RC VU+Version",
				where = PluginDescriptor.WHERE_PLUGINMENU,
				icon="multiquickbutton.png",
				fnc=main),
				PluginDescriptor(
				name="Multi Quickbutton",
				where = PluginDescriptor.WHERE_EXTENSIONSMENU,
				fnc=main),
				PluginDescriptor(
				name="Multi Quickbutton",
				description="Multi Quickbutton for Keyboard and RC VU+Version",
				where = PluginDescriptor.WHERE_MENU,
				fnc=menu)]
	else:
		return [PluginDescriptor(
				where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART],
				fnc = autostart),
				PluginDescriptor(
				name="Multi Quickbutton",
				description="Multi Quickbutton for Keyboard and RC VU+Version",
				where = PluginDescriptor.WHERE_PLUGINMENU,
				icon="multiquickbutton.png",
				fnc=main),
				PluginDescriptor(
				name="Multi Quickbutton",
				where = PluginDescriptor.WHERE_EXTENSIONSMENU,
				fnc=main)]
