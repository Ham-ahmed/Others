#!/bin/sh
wget -O /epg/epg.gz http://www.epgitalia.tv/gzip